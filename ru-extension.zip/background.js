// Background service worker — minimal, content script handles everything
